package com.example.vlad.mylastcamm

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata.LENS_FACING_BACK
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.util.Log
import android.util.Size
import android.view.*
import android.widget.FrameLayout

//class MainActivity : AppCompatActivity() {
import android.hardware.camera2.CameraMetadata.LENS_FACING_BACK

class MainActivity : Activity(), TextureView.SurfaceTextureListener, ActivityCompat.OnRequestPermissionsResultCallback {
    internal var ndkCamera_: Long = 0
    private var textureView_: TextureView? = null
    internal var surface_: Surface? = null
    private var cameraPreviewSize_: Size? = null
    private val isCamera2Device: Boolean
        get() {
            val camMgr = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var camera2Dev = true
            try {
                val cameraIds = camMgr.cameraIdList
                if (cameraIds.size != 0) {
                    for (id in cameraIds) {
                        val characteristics = camMgr.getCameraCharacteristics(id)
                        val deviceLevel = characteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)!!
                        val facing = characteristics.get(CameraCharacteristics.LENS_FACING)!!
                        if (deviceLevel == CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY && facing == LENS_FACING_BACK) {
                            camera2Dev = false
                        }
                    }
                }
            } catch (e: CameraAccessException) {
                e.printStackTrace()
                camera2Dev = false
            }

            return camera2Dev
        }

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onWindowFocusChanged(true)
        setContentView(R.layout.main)
        if (isCamera2Device) {
            RequestCamera()
        } else {
            Log.e("CameraSample", "Found legacy camera device, this sample needs camera2 device")
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    private fun createTextureView() {
        textureView_ = findViewById<TextureView>(R.id.texturePreview)
        textureView_!!.surfaceTextureListener = this
        if (textureView_!!.isAvailable) {
            onSurfaceTextureAvailable(
                textureView_!!.surfaceTexture,
                textureView_!!.width, textureView_!!.height
            )
        }
    }

    override fun onSurfaceTextureAvailable(
        surface: SurfaceTexture,
        width: Int, height: Int
    ) {
        createNativeCamera()

        resizeTextureView(width, height)
        surface.setDefaultBufferSize(
            cameraPreviewSize_!!.width,
            cameraPreviewSize_!!.height
        )
        surface_ = Surface(surface)
        onPreviewSurfaceCreated(ndkCamera_, surface_!!)
    }

    private fun resizeTextureView(textureWidth: Int, textureHeight: Int) {
        val rotation = windowManager.defaultDisplay.rotation
        var newHeight = textureWidth * cameraPreviewSize_!!.width / cameraPreviewSize_!!.height

        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            newHeight = textureWidth * cameraPreviewSize_!!.height / cameraPreviewSize_!!.width
        }
        textureView_!!.layoutParams = FrameLayout.LayoutParams(textureWidth, newHeight, Gravity.CENTER)
        configureTransform(textureWidth, newHeight)
    }

    /**
     * configureTransform()
     * Courtesy to https://github.com/google/cameraview/blob/master/library/src/main/api14/com/google/android/cameraview/TextureViewPreview.java#L108
     *
     * @param width  TextureView width
     * @param height is TextureView height
     */
    internal fun configureTransform(width: Int, height: Int) {
        val mDisplayOrientation = windowManager.defaultDisplay.rotation * 90
        val matrix = Matrix()
        if (mDisplayOrientation % 180 == 90) {
            //final int width = getWidth();
            //final int height = getHeight();
            // Rotate the camera preview when the screen is landscape.
            matrix.setPolyToPoly(
                floatArrayOf(
                    0f, 0f, // top left
                    width.toFloat(), 0f, // top right
                    0f, height.toFloat(), // bottom left
                    width.toFloat(), height.toFloat()
                )// bottom right
                , 0,
                if (mDisplayOrientation == 90)
                // Clockwise
                    floatArrayOf(
                        0f, height.toFloat(), // top left
                        0f, 0f, // top right
                        width.toFloat(), height.toFloat(), // bottom left
                        width.toFloat(), 0f
                    )// bottom right
                else
                // mDisplayOrientation == 270
                // Counter-clockwise
                    floatArrayOf(
                        width.toFloat(), 0f, // top left
                        width.toFloat(), height.toFloat(), // top right
                        0f, 0f, // bottom left
                        0f, height.toFloat()
                    )// bottom right
                , 0,
                4
            )
        } else if (mDisplayOrientation == 180) {
            matrix.postRotate(180f, (width / 2).toFloat(), (height / 2).toFloat())
        }
        textureView_!!.setTransform(matrix)
    }

    override fun onSurfaceTextureSizeChanged(
        surface: SurfaceTexture,
        width: Int, height: Int
    ) {
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        onPreviewSurfaceDestroyed(ndkCamera_, surface_)
        deleteCamera(ndkCamera_, surface_)
        ndkCamera_ = 0
        surface_ = null
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    fun RequestCamera() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                PERMISSION_REQUEST_CODE_CAMERA
            )
            return
        }
        createTextureView()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        /*
         * if any permission failed, the sample could not play
         */
        if (PERMISSION_REQUEST_CODE_CAMERA != requestCode) {
            super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
            )
            return
        }


        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            val initCamera = Thread(Runnable { runOnUiThread { createTextureView() } })
            initCamera.start()
        }
    }

    private fun createNativeCamera() {
        val display = windowManager.defaultDisplay
        val height = display.mode.physicalHeight
        val width = display.mode.physicalWidth

        ndkCamera_ = createCamera(width, height)

        cameraPreviewSize_ = getMinimumCompatiblePreviewSize(ndkCamera_)

    }

    /*
     * Functions calling into NDKCamera side to:
     *     CreateCamera / DeleteCamera object
     *     Start/Stop Preview
     *     Pulling Camera Parameters
     */
    private external fun createCamera(width: Int, height: Int): Long

    private external fun getMinimumCompatiblePreviewSize(ndkCamera: Long): Size

    private external fun onPreviewSurfaceCreated(ndkCamera: Long, surface: Surface)

    private external fun onPreviewSurfaceDestroyed(ndkCamera: Long, surface: Surface?)

    private external fun deleteCamera(ndkCamera: Long, surface: Surface?)

    companion object {

        private val PERMISSION_REQUEST_CODE_CAMERA = 1

        init {
            System.loadLibrary("ndk_camera")
        }
    }

}
